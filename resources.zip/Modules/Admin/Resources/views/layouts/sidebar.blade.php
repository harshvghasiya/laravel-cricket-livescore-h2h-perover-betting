<?php 
   
   $moduleData = \App\Models\RightModule::where('right_id',\Auth::user()->right_id)->pluck('module_id')->toArray();
?>
<div class="sidebar-wrapper" data-simplebar="true">
            <div class="sidebar-header">
                <div >
                    <img @if(isset($setting))src="{{$setting->getLogoImageUrl()}}"@endif style="height: 46px;" class="logo-icon" alt="logo icon">
                </div>
                <div>
                    <h4 class="logo-text">@if(isset($setting)){{$setting->website_title}} @endif</h4>
                </div>
                
                <div class="toggle-icon ms-auto"><i class='bx bx-arrow-to-left'></i>
                </div>
            </div>
            <!--navigation-->
            <ul class="metismenu" id="menu">
                <li>
                    <a href="{{route('admin.dashboard')}}" >
                        <div class="parent-icon"><i class='bx bx-home-circle'></i>
                        </div>
                        <div class="menu-title">{{trans('message.dashboard')}}</div>
                    </a>
                </li>
                
                 @php
                  if (
                       \Route::is('admin.'.EMAIL_TEMPLATE_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.EMAIL_TEMPLATE_ROUTE_NAME().'create')||
                       \Route::is('admin.'.EMAIL_TEMPLATE_ROUTE_NAME().'edit') 
                   ) {
                      $mainliclass="mm-active";
                      $ulclass="mm-show mm-collapse";

                  }else{
                    $mainliclass="";
                    $ulclass="";
                  }
                @endphp 

                @if(
                    in_array(\App\Models\RightModule::CONST_LOGO_SETTING,$moduleData) || 
                    in_array(\App\Models\RightModule::CONST_FAVICON_SETTING,$moduleData) ||
                    in_array(\App\Models\RightModule::CONST_SCRIPT_SETTING,$moduleData) || 
                    in_array(\App\Models\RightModule::CONST_MAIL_SETTING,$moduleData) ||
                    in_array(\App\Models\RightModule::CONST_EMAIL_TEMPLATE_SETTING,$moduleData)
                   )
                 <li class="{{$mainliclass}}">
                    <a href="javascript:;" class="has-arrow">
                        <div class="parent-icon"><i class="bx bx-category"></i>
                        </div>
                        <div class="menu-title">{{trans('message.basic_setting')}}</div>
                    </a>
                    <ul class="{{$ulclass}}">

                        @if(in_array(\App\Models\RightModule::CONST_LOGO_SETTING,$moduleData))
                            <li> <a href="{{ route('admin.basic_setting.logo') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.logo_setting')}}</a>
                            </li>
                        @endif
                        @if(in_array(\App\Models\RightModule::CONST_FAVICON_SETTING,$moduleData))
                        <li> <a href="{{ route('admin.basic_setting.favicon') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.favicon_setting')}}</a>
                        </li>
                        @endif
                        @if(in_array(\App\Models\RightModule::CONST_SCRIPT_SETTING,$moduleData))
                        <li> <a href="{{ route('admin.basic_setting.script') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.script_basic_settings')}}</a>
                        </li>   
                        @endif
                        @if(in_array(\App\Models\RightModule::CONST_MAIL_SETTING,$moduleData))
                        <li> <a href="{{ route('admin.basic_setting.mail_config') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.mail_config_settings')}}</a>
                        </li>
                        @endif
                        @if(in_array(\App\Models\RightModule::CONST_EMAIL_TEMPLATE_SETTING,$moduleData))
                        <li  @if(\Route::is('admin.'.EMAIL_TEMPLATE_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.EMAIL_TEMPLATE_ROUTE_NAME().'create')||
                       \Route::is('admin.'.EMAIL_TEMPLATE_ROUTE_NAME().'edit')) class="mm-active" @endif> <a href="{{ route('admin.email_template.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.email_template')}}</a>
                        </li>
                        @endif
                    </ul>
                </li>
                @endif

                @php
                  if ( \Route::is('admin.'.RIGHT_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.RIGHT_ROUTE_NAME().'create')||
                       \Route::is('admin.'.RIGHT_ROUTE_NAME().'edit') ||

                       \Route::is('admin.'.MODULE_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.MODULE_ROUTE_NAME().'create')||
                       \Route::is('admin.'.MODULE_ROUTE_NAME().'edit') ||

                       \Route::is('admin.'.ADMIN_USER_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.ADMIN_USER_ROUTE_NAME().'create')||
                       \Route::is('admin.'.ADMIN_USER_ROUTE_NAME().'edit') 
                   ) {
                      $mainliclass="mm-active";
                      $ulclass="mm-show mm-collapse";

                  }else{
                    $mainliclass="";
                    $ulclass="";
                  }
                @endphp 

                @if(\Auth::user()->is_admin==1)
                <li class="{{$mainliclass}}">
                    <a href="javascript:;" class="has-arrow">
                        <div class="parent-icon"><i class="bx bx-lock"></i>
                        </div>
                        <div class="menu-title">{{trans('message.admin_management')}}</div>
                    </a>
                    <ul class="{{$ulclass}}">
                        <li @if(\Route::is('admin.'.RIGHT_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.RIGHT_ROUTE_NAME().'create')||
                       \Route::is('admin.'.RIGHT_ROUTE_NAME().'edit')) class="mm-active" @endif> <a href="{{ route('admin.right.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.right_setting')}}</a>
                        </li>
                        <li @if(\Route::is('admin.'.MODULE_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.MODULE_ROUTE_NAME().'create')||
                       \Route::is('admin.'.MODULE_ROUTE_NAME().'edit')) class="mm-active" @endif> <a href="{{ route('admin.module.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.module_setting')}}</a>
                        </li>
                        <li @if(\Route::is('admin.'.ADMIN_USER_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.ADMIN_USER_ROUTE_NAME().'create')||
                       \Route::is('admin.'.ADMIN_USER_ROUTE_NAME().'edit')) class="mm-active" @endif> <a href="{{ route('admin.admin_user.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.admin_user_setting')}}</a>
                        </li>

                    </ul>
                </li>
                @endif
                 
                @php
                  if ( \Route::is('admin.'.COUNTRY_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.COUNTRY_ROUTE_NAME().'create')||
                       \Route::is('admin.'.COUNTRY_ROUTE_NAME().'edit') ||

                       \Route::is('admin.'.STATE_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.STATE_ROUTE_NAME().'create')||
                       \Route::is('admin.'.STATE_ROUTE_NAME().'edit') ||

                       \Route::is('admin.'.CITY_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.CITY_ROUTE_NAME().'create')||
                       \Route::is('admin.'.CITY_ROUTE_NAME().'edit') ||

                       \Route::is('admin.'.LOCATION_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.LOCATION_ROUTE_NAME().'create')||
                       \Route::is('admin.'.LOCATION_ROUTE_NAME().'edit') 
                   ) {
                      $mainliclass="mm-active";
                      $ulclass="mm-show mm-collapse";

                  }else{
                    $mainliclass="";
                    $ulclass="";
                  }
                @endphp 
                @if(
                    in_array(\App\Models\RightModule::CONST_COUNTRY_SETTING,$moduleData) || 
                    in_array(\App\Models\RightModule::CONST_STATE_SETTING,$moduleData) ||
                    in_array(\App\Models\RightModule::CONST_LOCATION_SETTING,$moduleData) ||
                    in_array(\App\Models\RightModule::CONST_CITY_SETTING,$moduleData) 
                   )
                <li  class="{{$mainliclass}}">
                    <a href="javascript:;" class="has-arrow">
                        <div class="parent-icon"><i class="fadeIn animated bx bx-current-location"></i>
                        </div>
                        <div class="menu-title">{{trans('message.location_management')}}</div>
                    </a>
                    <ul class="{{$ulclass}}">
                        @if(in_array(\App\Models\RightModule::CONST_LOCATION_SETTING,$moduleData))
                        <li @if(\Route::is('admin.'.LOCATION_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.LOCATION_ROUTE_NAME().'create')||
                       \Route::is('admin.'.LOCATION_ROUTE_NAME().'edit')) class="mm-active" @endif> <a href="{{ route('admin.location.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.location')}}</a>
                        </li>
                        @endif
                        @if(in_array(\App\Models\RightModule::CONST_COUNTRY_SETTING,$moduleData))
                        <li @if(\Route::is('admin.'.COUNTRY_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.COUNTRY_ROUTE_NAME().'create')||
                       \Route::is('admin.'.COUNTRY_ROUTE_NAME().'edit')) class="mm-active" @endif> <a href="{{ route('admin.country.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.country')}}</a>
                        </li>
                        @endif
                        @if(in_array(\App\Models\RightModule::CONST_STATE_SETTING,$moduleData))
                        <li @if(\Route::is('admin.'.STATE_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.STATE_ROUTE_NAME().'create')||
                       \Route::is('admin.'.STATE_ROUTE_NAME().'edit')) class="mm-active"  @endif > <a href="{{ route('admin.state.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.state')}}</a>
                        </li>
                        @endif
                        @if(in_array(\App\Models\RightModule::CONST_CITY_SETTING,$moduleData))
                        <li @if(\Route::is('admin.'.CITY_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.CITY_ROUTE_NAME().'create')||
                       \Route::is('admin.'.CITY_ROUTE_NAME().'edit')) class="mm-active"  @endif > <a href="{{ route('admin.city.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.city')}}</a>
                        </li>
                        @endif
                    </ul>
                </li>
                @endif
                

                @php
                  if ( \Route::is('admin.'.COMPANY_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.COMPANY_ROUTE_NAME().'create')||
                       \Route::is('admin.'.COMPANY_ROUTE_NAME().'edit') ||
                       \Route::is('admin.'.COMPANY_ROUTE_NAME().'view') ||

                       \Route::is('admin.'.COMPANY_CATEGORY_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.COMPANY_CATEGORY_ROUTE_NAME().'create')||
                       \Route::is('admin.'.COMPANY_CATEGORY_ROUTE_NAME().'edit') ||

                       \Route::is('admin.'.ACTIVITY_SUBJECT_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.ACTIVITY_SUBJECT_ROUTE_NAME().'create')||
                       \Route::is('admin.'.ACTIVITY_SUBJECT_ROUTE_NAME().'edit') ||

                       \Route::is('admin.'.CONTACT_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.CONTACT_ROUTE_NAME().'create')||
                       \Route::is('admin.'.CONTACT_ROUTE_NAME().'edit') ||

                       \Route::is('admin.'.ACTIVITY_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.ACTIVITY_ROUTE_NAME().'create')||
                       \Route::is('admin.'.ACTIVITY_ROUTE_NAME().'edit') 
                   ) {
                      $mainliclass="mm-active";
                      $ulclass="mm-show mm-collapse";

                  }else{
                    $mainliclass="";
                    $ulclass="";
                  }
                @endphp 

                @if(
                    in_array(\App\Models\RightModule::CONST_COMPANY_SETTING,$moduleData) || 
                    in_array(\App\Models\RightModule::CONST_COMPANY_CATEGORY_SETTING,$moduleData) ||
                    in_array(\App\Models\RightModule::CONST_ACTIVITY_SUBJECT_SETTING,$moduleData) ||
                    in_array(\App\Models\RightModule::CONST_ACTIVITY_SETTING,$moduleData) ||
                    in_array(\App\Models\RightModule::CONST_CONTACT_SETTING,$moduleData) 
                   )
                <li class="{{$mainliclass}}">
                    <a href="javascript:;" class="has-arrow">
                        <div class="parent-icon"><i class="fadeIn animated bx bx-border-all"></i>
                        </div>
                        <div class="menu-title">{{trans('message.company_management')}}</div>
                    </a>
                    <ul class="{{$ulclass}}">

                        @if(in_array(\App\Models\RightModule::CONST_COMPANY_SETTING,$moduleData))
                        <li @if(\Route::is('admin.'.COMPANY_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.COMPANY_ROUTE_NAME().'create')||
                       \Route::is('admin.'.COMPANY_ROUTE_NAME().'edit') || \Route::is('admin.'.COMPANY_ROUTE_NAME().'view') ) class="mm-active" @endif> <a href="{{ route('admin.company.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.company')}}</a>
                        </li>
                        @endif

                        @if(in_array(\App\Models\RightModule::CONST_COMPANY_CATEGORY_SETTING,$moduleData))
                        <li @if(\Route::is('admin.'.COMPANY_CATEGORY_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.COMPANY_CATEGORY_ROUTE_NAME().'create')||
                       \Route::is('admin.'.COMPANY_CATEGORY_ROUTE_NAME().'edit')) class="mm-active" @endif> <a href="{{ route('admin.company_category.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.company_category')}}</a>
                        </li>
                        @endif

                        @if(in_array(\App\Models\RightModule::CONST_ACTIVITY_SUBJECT_SETTING,$moduleData))
                        <li @if(\Route::is('admin.'.ACTIVITY_SUBJECT_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.ACTIVITY_SUBJECT_ROUTE_NAME().'create')||
                       \Route::is('admin.'.ACTIVITY_SUBJECT_ROUTE_NAME().'edit')) class="mm-active" @endif> <a href="{{ route('admin.activity_subject.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.activity_subject')}}</a>
                        </li>
                        @endif
                         @if(in_array(\App\Models\RightModule::CONST_CONTACT_SETTING,$moduleData))
                        <li @if(\Route::is('admin.'.CONTACT_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.CONTACT_ROUTE_NAME().'create')||
                       \Route::is('admin.'.CONTACT_ROUTE_NAME().'edit')) class="mm-active" @endif> <a href="{{ route('admin.contact.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.contact')}}</a>
                        </li>
                        @endif
                         @if(in_array(\App\Models\RightModule::CONST_ACTIVITY_SETTING,$moduleData))
                        <li @if(\Route::is('admin.'.ACTIVITY_ROUTE_NAME().'index') ||
                       \Route::is('admin.'.ACTIVITY_ROUTE_NAME().'create')||
                       \Route::is('admin.'.ACTIVITY_ROUTE_NAME().'edit')) class="mm-active" @endif> <a href="{{ route('admin.activity.index') }}"><i class="bx bx-right-arrow-alt"></i>{{trans('message.activity')}}</a>
                        </li>
                        @endif
                    </ul>
                </li>
                @endif

                @if(in_array(\App\Models\RightModule::CONST_SUPPORT_SETTING,$moduleData))
                <li>
                    <a href="{{route('admin.support.index')}}"  aria-expanded="true">
                        <div class="parent-icon"><i class="bx bx-support"></i>
                        </div>
                        <div class="menu-title">{{trans('message.support_title')}}</div>
                    </a>
                </li>
                @endif
               
            </ul>
            <!--end navigation-->
        </div>
        <!--end sidebar wrapper -->